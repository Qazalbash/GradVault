Augerat, P. (1995). Approche polyédrale du problème de tournées de véhicules, PhD thesis, Institut National Polytechnique de Grenoble, France.
------------------------------------------------------------------------------------------
Remarks:
 - <node>: attribute type=0 for the depot and 1 for customer nodes
 - <decimals>: Unfortunately there is no standard rounding rule for this dataset in the literature. Since the VRP-REP format (V.1.0.0) requires a rounding rule we suggest to round the distances to the closest integer value, following the TSPLIB standard. Be aware, however, that this is not necessarily the rounding rule used by the algorithms which delivered the best known solutions for the dataset registered in the VRP-REP platform.
 
  